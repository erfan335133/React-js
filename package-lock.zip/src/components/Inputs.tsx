import { useEffect, useState } from "react";
import Button from "./Button";

const Inputs = ({ addUser }) => {
  const [name, setName] = useState("");
  const [pass, setPass] = useState("");
  const [rePass, setRePass] = useState("");
  const [email, setEmail] = useState("");
  const [color, setColor] = useState("");
  const [eror, setEror] = useState("");
  const [newUser, setNewuUser] = useState({});

  const msg = (color, msg) => {
    setColor(color);
    setEror(msg);
    setTimeout(() => {
      setColor("");
      setEror("");
    }, 3000);
  };

  const send = () => {
    if (name.length < 5) {
      return msg("red", "Name should be more than 5 charector");
    }
    if (pass.length < 8) {
      return msg("red", "Password should be more than or equal to 8 charector");
    }
    if (!/[A-Z]/.test(pass)) {
      return msg("red", "Password should have charector between A to Z");
    }
    if (!/[0-9]/.test(pass)) {
      return msg("red", "Password should have number between 0 to 9");
    }
    if (!/[!@#$%&*]/.test(pass)) {
      return msg("red", "Password should have charector between !@#$%&*");
    }
    if (pass !== rePass) {
      return msg("red", "Password should equal to rePassword");
    }
    if (!/.com$/.test(email)) {
      return msg("red", "Email should end with `.com`");
    }
    if (!/[@]/.test(email)) {
      return msg("red", "Email should have `@` charector");
    }

    msg("green", "Your are registered successfully ...");

    addUser({
      userName: name,
      userPassword: pass,
      userEmail: email,
    });
    //   fetch("https://jsonplaceholder.typicode.com/posts", {
    //     method: "POST",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     body: JSON.stringify({
    //       name: name,
    //       password: pass,
    //       email: email,
    //     }),
    //   })
    //     .then((res) => res.json())
    //     .then((data) => console.log(data));
    // };

    localStorage.setItem(
      "usersData",
      JSON.stringify({
        userName: name,
        userPassword: pass,
        userEmail: email,
      })
    );

    console.log(localStorage.getItem("usersData"));
  };

  return (
    <>
      <input
        className="input"
        type="text"
        placeholder="Enter user name : "
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        className="input"
        type="password"
        placeholder="Enter password : "
        value={pass}
        onChange={(e) => setPass(e.target.value)}
      />
      <input
        className="input"
        type="password"
        placeholder="Enter password again : "
        value={rePass}
        onChange={(e) => setRePass(e.target.value)}
      />
      <input
        className="input"
        type="email"
        placeholder="Enter email : "
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <Button onclick={send} />
      <div
        className="eror"
        style={{
          position: "absolute",
          top: "20px",
          right: "20px",
          display: color ? "flex" : "none",
          justifyContent: "center",
          width: "300px",
          height: "50px",
          alignItems: "center",
          textAlign: "center",
          borderRadius: "10px",
          color: "white",
          backgroundColor: color == "red" ? "red" : "green",
        }}
      >
        {eror}
      </div>
    </>
  );
};

export default Inputs;
