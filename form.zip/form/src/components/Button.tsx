const Button = ({ onclick }) => {
  return (
    <>
      <button onClick={onclick}>Register</button>
    </>
  );
};

export default Button;
