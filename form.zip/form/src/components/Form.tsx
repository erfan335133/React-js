import { useState } from "react";
import "./Form.css";
import Inputs from "./Inputs";

const Form = () => {
  const [users, setUsers] = useState([]);
  const addUser = (newUser) => {
    setUsers((prev) => [...prev, newUser]);
  };
  return (
    <div className="all">
      <h1>Register Form</h1>
      <div className="form">
        <Inputs addUser={addUser} />
      </div>
    </div>
  );
};

export default Form;
